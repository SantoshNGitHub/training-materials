public interface PriceCalculator {

  String calculatePrice();

}
