public interface DisplayObject {

  void display();

}
