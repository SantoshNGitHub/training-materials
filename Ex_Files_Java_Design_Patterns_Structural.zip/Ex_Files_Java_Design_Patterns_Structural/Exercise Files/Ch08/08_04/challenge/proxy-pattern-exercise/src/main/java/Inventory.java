import java.util.ArrayList;

public interface Inventory {

  ArrayList<Item> getInventory();

}
