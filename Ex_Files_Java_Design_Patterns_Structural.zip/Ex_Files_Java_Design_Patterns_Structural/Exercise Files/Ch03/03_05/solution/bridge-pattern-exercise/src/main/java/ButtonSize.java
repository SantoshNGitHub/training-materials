public interface ButtonSize {

  void getSize();

}



