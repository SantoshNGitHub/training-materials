public abstract class Button {

  abstract void draw();

}
