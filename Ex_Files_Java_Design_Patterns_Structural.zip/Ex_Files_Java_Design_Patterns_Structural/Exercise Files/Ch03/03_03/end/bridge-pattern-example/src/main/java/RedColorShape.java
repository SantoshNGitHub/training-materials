import java.awt.Color;
import java.awt.Graphics;

public class RedColorShape implements ColorShape {

  public void setColor(Graphics graphics) {
    graphics.setColor(Color.RED);
  }

}
