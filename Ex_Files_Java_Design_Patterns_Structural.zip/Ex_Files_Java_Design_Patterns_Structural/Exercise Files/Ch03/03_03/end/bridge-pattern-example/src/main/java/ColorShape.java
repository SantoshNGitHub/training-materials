import java.awt.Graphics;

public interface ColorShape {

  void setColor(Graphics graphics);

}
