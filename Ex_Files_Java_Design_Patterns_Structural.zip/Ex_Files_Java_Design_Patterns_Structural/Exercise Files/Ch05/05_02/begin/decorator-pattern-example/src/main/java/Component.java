import java.awt.Graphics;

public interface Component {

  void draw(Graphics graphics);

}
