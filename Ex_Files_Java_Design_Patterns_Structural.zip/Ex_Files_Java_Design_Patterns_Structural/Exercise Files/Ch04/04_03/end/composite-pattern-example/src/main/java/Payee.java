public interface Payee {

  void payExpenses(int amount);

}
