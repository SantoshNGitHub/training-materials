public interface Books {

  void checkout();
  void returnBook();

}



